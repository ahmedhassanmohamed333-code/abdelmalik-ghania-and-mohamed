# 🏆 Faseeh Academy — Arabic & Quran Champions Arena

Interactive classroom competition web app built for **Ustadh Ahmed Hassan (أكاديمية فصيح)** featuring:
- **Contestants:** Abdulmalik 🏋️‍♂️💪, Ghaniya 👩‍⚕️🩺, and Mohammed 🧠🚀
- **Quranic & Arabic Tashkeel Spelling Lab:** Interactive syllable-by-syllable pronunciation and spelling with full Harakat.
- **Editable Lesson Verses & Quiz:** Customize verses and vocabulary directly inside the browser (`✏️ Update Lesson / Verses`).
- **Bilingual Riddles & Comedy Break:** Interactive Fawazeer and classroom jokes in English & Arabic.
- **Mystery Chests, Lucky Draw & Mini-Games:** 3-Player Connect 4, X-O Duel, and confetti victory celebrations.

## 🚀 How to Deploy on GitHub Pages
1. Create a new repository on GitHub (or open your existing repository).
2. Upload `index.html` (and optionally this `README.md`) to the root of the repository.
3. Go to **Settings** → **Pages** → under **Branch**, select `main` (and `/root`) and click **Save**.
4. Your live interactive classroom game will be published within 1 minute!
